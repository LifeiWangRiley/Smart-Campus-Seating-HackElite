import React from 'react';

function Cafeteria() {
  return (
    <div>
      <h2>Cafeteria Seat Map</h2>
      {/* Display cafeteria seat map */}
    </div>
  );
}

export default Cafeteria;