import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

function Navbar() {
    return (
        <nav className="navbar navbar-expand-lg custom-navbar">
        <Link className="navbar-brand custom-brand" to="/">Seat Map App</Link>
        <button
          className="navbar-toggler custom-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon custom-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse custom-collapse" id="navbarNav">
          <ul className="navbar-nav ml-auto">
            <li className="nav-item">
              <Link className="nav-link custom-nav-link" to="/classroom">Classroom</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link custom-nav-link" to="/library">Library</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link custom-nav-link" to="/cafeteria">Cafeteria</Link>
            </li>
          </ul>
        </div>
      </nav>
    );
  }
  
  export default Navbar;