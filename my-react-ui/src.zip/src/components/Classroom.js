import React from 'react';

function Classroom(){
    return (
        <div>
            <h2>Classroom Seat Map</h2>
            {/* Classroom seat map */}
        </div>
    );
}

export default Classroom;