import React from 'react';
import './Home.css';

function Home(){
    return (
      <div className="home-container">
      <div className="text-center home-content">
        <h2 className="home-title">Welcome to Seat Map App</h2>
        <p className="home-subtitle">Select a location:</p>
        <div className="button-container">
          <button className="custom-button btn-classroom">Classroom</button>
          <button className="custom-button btn-library">Library</button>
          <button className="custom-button btn-cafeteria">Cafeteria</button>
        </div>
      </div>
    </div>
    );
}

export default Home;