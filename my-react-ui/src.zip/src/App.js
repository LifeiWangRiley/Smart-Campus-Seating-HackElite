// import logo from './logo.svg';
import './App.css';
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './components/Home';
import Classroom from './components/Classroom';
import Library from './components/Library';
import Cafeteria from './components/Cafeteria';
// import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './components/Navbar';



function App() {
  return (
      <Router>
        <div>
          <Navbar />
          <Routes>
            <Route path="/" exact component={Home} />
            <Route path="/classroom" component={Classroom} />
            <Route path="/library" component={Library} />
            <Route path="/cafeteria" component={Cafeteria} />
          </Routes>
        </div>
      </Router>
  );
}

export default App;
